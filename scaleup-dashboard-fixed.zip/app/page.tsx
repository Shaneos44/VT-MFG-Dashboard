"use client";
import ScaleUpDashboard from "@/components/ScaleUpDashboard";

export default function Page() {
  return <ScaleUpDashboard />;
}
